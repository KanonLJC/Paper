from utils.registry import Registry

BACKBONES = Registry()
HEADS = Registry()
PREDICTOR = Registry()
