The folder of experimental results.
