#/bin/bash
g++ -o evaluate_object_3d_offline_ap11 evaluate_object_3d_offline_ap11.cpp
g++ -o evaluate_object_3d_offline_ap40 evaluate_object_3d_offline_ap40.cpp
