from .vovnet import VoVNet

__all__ = ['VoVNet']